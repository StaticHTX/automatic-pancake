"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Github, Mail, Linkedin, Link } from "lucide-react"

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="text-center mb-10">
        <img src="/voltice-logo.png" alt="Voltice Crystal Logo" className="mx-auto w-48 mb-4" />
        <h1 className="text-4xl font-bold">Voltice Crystal</h1>
        <p className="text-lg text-gray-600">Powerful Thinking, Precision Execution — Where Lightning Meets Diamond</p>
        <div className="mt-4 flex justify-center gap-4">
          <Button variant="outline" size="icon"><Linkedin /></Button>
          <Button variant="outline" size="icon"><Github /></Button>
          <Button variant="outline" size="icon"><Mail /></Button>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">About</h2>
            <p>
              Voltice Crystal is the digital portfolio of Christopher Bailey — a sales strategist with technical precision. 
              Combining data, automation, and customer-focused strategy to drive impact at scale.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Core Skills</h2>
            <ul className="list-disc list-inside space-y-1">
              <li>Strategic Sales Execution</li>
              <li>CRM / Data-Driven Outreach</li>
              <li>Python Scripting & Automation</li>
              <li>Customer Experience Optimization</li>
              <li>Cloud & Network Support</li>
            </ul>
          </CardContent>
        </Card>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-bold mb-4">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold text-lg mb-1">Lead Gen Automation</h3>
              <p>
                Custom Python scripts built to automate lead scraping and formatting, saving hours of manual outreach.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold text-lg mb-1">Sales Playbook Framework</h3>
              <p>
                Internal training resource for new hires, crafted to scale B2B outreach at ByteReach Solutions.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mb-10 text-center">
        <h2 className="text-2xl font-bold mb-4">Links</h2>
        <div className="flex justify-center gap-4 flex-wrap">
          <a href="https://linkedin.com/in/yourprofile" className="text-blue-600 hover:underline flex items-center gap-1"><Link size={16} />LinkedIn</a>
          <a href="https://github.com/yourusername" className="text-gray-800 hover:underline flex items-center gap-1"><Link size={16} />GitHub</a>
          <a href="mailto:your@email.com" className="text-red-600 hover:underline flex items-center gap-1"><Link size={16} />Email Me</a>
          <a href="https://yourportfolio.com" className="text-purple-600 hover:underline flex items-center gap-1"><Link size={16} />Website</a>
        </div>
      </section>

      <footer className="text-center text-sm text-gray-500 mt-10">
        © {new Date().getFullYear()} Voltice Crystal. All rights reserved.
      </footer>
    </div>
  )
}
